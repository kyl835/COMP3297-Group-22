from django.db import models
from django.contrib import admin
from django.db.models import Sum, Count
from enum import Enum
from django_mysql.models import EnumField
from enumchoicefield import ChoiceEnum, EnumChoiceField

# Create your models here.

class Category(models.Model):
	name = models.CharField(max_length=200)
	def __str__(self):
		return self.name

class Item(models.Model):
	category = models.ForeignKey(Category, on_delete=models.CASCADE)
	quantity = models.IntegerField()	
	def __str__(self):
		return self.id



