from django.apps import AppConfig


class AirsupplyConfig(AppConfig):
    name = 'AirSupply'
