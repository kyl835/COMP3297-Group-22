from django.urls import path
from AirSupply import views

urlpatterns = [
	path('category', views.CategoryViewAll.as_view(), name='category'),
]
